package Activies;
public class ASCII_CODES {
    public static void main(String[] args) {
        System.out.println("\nASCII CODES - using FOR LOOP");
        System.out.println("LOWER CASE | UPPER CASE");
        for (int letter = 0 + 65; letter < 26 + 65; letter++) {
            System.out.printf("%c (%d) | %c (%d)\n",
                    letter + 32, letter + 32, letter, letter);
        } 
    }
}
