package Activies;

import java.util.Scanner;
public class ODD_OR_EVEN {
     
        public static void main(String[] args) { 
        
           Scanner input = new Scanner(System.in);
           int n;
           
           System.out.println("\nODD OR EVEN");
           System.out.printf("input an integer value for N: ");
           n = input.nextInt();

           if (n >= 2 && n <= 100) {
           System.out.printf("%d - ", n);
           if (n % 2 == 0) {
                System.out.println("EVEN");
           } else {
                System.out.println("ODD");
           }
           } else {
           System.out.printf("Input no. between 2 and 100.");
        }
    }
}
